import java.util.Arrays;
import java.util.ArrayList;
import java.util.Random;

public class Task1 {

	private static int[] merge(int[] arr1, int[] arr2) {
		int size1 = arr1.length;
		int size2 = arr2.length;
		int i=0,j=0,k=0;
		int[] result = new int[arr1.length + arr2.length];
		while(i<arr1.length || j < arr2.length)
			{
				if (i < arr1.length && j < arr2.length)
				{
					if(arr1[i] < arr2[j])
					{
						result[k++]=arr1[i++];
					}
					else
					{
						result[k++]=arr2[j++];
					}
				}
				else if(i < arr1.length)
				{
					result[k++] = arr1[i++];
				}
				else if(j < arr2.length)
				{
					result[k++] = arr2[j++];
				}
			}
		arr1 = result;
		return arr1;
	}
	private static int[][] slice(int[] arr, int k) {
		int arrsize = (arr.length / k ) ;
		int extra = arr.length % k;
		int kextra = k+extra;
		int[][] ret=new int[kextra][arrsize];
		for(int idx=(kextra-1); idx<kextra; idx++)
		{
			for(int jdx=0; jdx<arrsize; jdx++)
			{
				ret[idx][jdx]=Integer.MAX_VALUE;
			}
		}
		int idx1d=0;
		for(int idx=0; idx<kextra; idx++)
		{
			for(int jdx=0; jdx<arrsize && idx1d<arr.length; jdx++)
			{
				ret[idx][jdx]=arr[idx1d++];
			}
		}
		
		return ret;
	}

	public static int[] sort(int[] array) {
		int cores = Runtime.getRuntime().availableProcessors();
		int[][] arrs = slice(array,cores);
		ArrayList<Thread> Threads = new ArrayList<>();
		for(int[] yeah : arrs)
		{
			Thread sorter = new Thread(()-> Arrays.sort(yeah));
			sorter.start();
			Threads.add(sorter);
		}

		int[] sorted = new int[array.length];
		try{
			for(Thread thread : Threads)
			{
				thread.join();
			}
		}
		catch(InterruptedException e)
		{
		System.out.println("asd");
		}
		for(int[] yeah : arrs)
		{
		merge(sorted,yeah);
		}
		return sorted;
	}

	public static void main(String[] args) {
		int[] myarr = new int[10000];
		Random rand = new Random();
		for(int idx=0; idx<myarr.length;idx++)
		{
		myarr[idx] = Math.abs(rand.nextInt())%15000;
		}
		sort(myarr);
	}
}
