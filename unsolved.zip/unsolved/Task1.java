import java.util.Arrays;
import java.util.ArrayList;
import java.util.Random;

public class Task1 {

  private static int[] merge(int[] arr1, int[] arr2) {
    int size1 = arr1.length;
    int size2 = arr2.length;
    int i=0, j=0;
    while (j<size2 && i<size1)
        {
            if (arr1[i] < arr2[j])
            {
              i++;
            }
            else
            {
              for(int idx= arr1.length-1; idx>i; idx--)
              {
                arr1[idx] = arr1[idx-1];
              }
              arr1[i] = arr2[j++];
            }
        }
    return arr1;
  }
  private static int[][] slice(int[] arr, int k) {
    int arrsize = (arr.length / k ) ;
    int extra = arr.length % k;
    int kextra = k+extra;
    int[][] ret=new int[kextra][arrsize];
    int idx1d=0;
    for(int idx=0; idx<k; idx++)
    {
        for(int jdx=0; jdx<arrsize && idx1d<arr.length; jdx++)
        {
            ret[idx][jdx]=arr[idx1d++];
        }
    }
    
    return ret;
  }

  public static int[] sort(int[] array) {
    int cores = Runtime.getRuntime().availableProcessors();
    int[][] arrs = slice(array,cores);
    ArrayList<Thread> Threads = new ArrayList<>();
    for(int[] yeah : arrs)
    {
        Thread sorter = new Thread(()-> Arrays.sort(yeah));
        sorter.start();
        Threads.add(sorter);
    }
    try{
        for(Thread thread : Threads)
        {
            thread.join();
        }
    }
    catch(InterruptedException e)
    {
        System.out.println(e.toString());
    }

    int[] sorted = new int[array.length];
    for(int idx=0; idx<sorted.length;idx++)
    {
      sorted[idx] = Integer.MAX_VALUE;
    }
      for(int[] yeah : arrs)
    {
      merge(sorted,yeah);
    }

    for(int idx : sorted)
    { 
      System.out.println("sorted: " + idx);
    }
    return sorted;
  }

  public static void main(String[] args) {
    int[] myarr = new int[100000];
    Random rand = new Random();
    for(int idx=0; idx<myarr.length;idx++)
    {
      myarr[idx] = Math.abs(rand.nextInt())%15000;
    }
    sort(myarr);
  }
}
